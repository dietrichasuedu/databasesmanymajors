DROP TABLE Take;
DROP TABLE Courses;
DROP TABLE Students;
