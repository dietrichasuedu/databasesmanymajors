DROP TABLE Observed;
DROP TABLE Particles;
DROP TABLE Timesteps;
