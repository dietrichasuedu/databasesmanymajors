DELETE FROM Observed;
DELETE FROM Particles;
DELETE FROM Timesteps;
