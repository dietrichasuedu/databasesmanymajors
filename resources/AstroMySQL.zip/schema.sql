CREATE TABLE Particles(mass double,iOrd int,temp double,type VARCHAR(10), PRIMARY KEY (iOrd));
CREATE TABLE Timesteps(stepID int,gigayears double,redshift double, PRIMARY KEY (stepID));
CREATE TABLE Observed(iOrd int,stepID int,grpID int, PRIMARY KEY (iOrd,stepID),  FOREIGN KEY (iOrd) REFERENCES Particles(iOrd) , FOREIGN KEY (stepID) REFERENCES Timesteps(stepID));
