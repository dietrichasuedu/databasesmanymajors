DELETE FROM Testing;
DELETE FROM Treatments;
DELETE FROM Sites;
