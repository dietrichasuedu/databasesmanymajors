DROP TABLE Testing;
DROP TABLE Treatments;
DROP TABLE Sites;
