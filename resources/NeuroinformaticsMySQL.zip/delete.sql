DELETE FROM Ephys;
DELETE FROM Neuron;
DELETE FROM Protocol;

