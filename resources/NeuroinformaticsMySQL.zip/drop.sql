DROP TABLE Ephys;
DROP TABLE Neuron;
DROP TABLE Protocol;

