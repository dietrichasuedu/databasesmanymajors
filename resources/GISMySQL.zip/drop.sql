DROP TABLE RiversInCountries;
DROP TABLE Rivers;
DROP TABLE Countries;
