DELETE FROM RiversInCountries;
DELETE FROM Rivers;
DELETE FROM Countries;
