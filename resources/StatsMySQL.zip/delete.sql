DELETE FROM MatchUps;
DELETE FROM Pitchers;
DELETE FROM Hitters;
