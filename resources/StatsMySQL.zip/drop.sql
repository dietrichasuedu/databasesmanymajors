DROP TABLE MatchUps;
DROP TABLE Pitchers;
DROP TABLE Hitters;
