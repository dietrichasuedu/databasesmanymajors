DROP TABLE SequenceData;
DROP TABLE Gene;
DROP TABLE Specimen;
