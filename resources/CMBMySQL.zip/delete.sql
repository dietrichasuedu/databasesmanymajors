DELETE FROM SequenceData;
DELETE FROM Gene;
DELETE FROM Specimen;
