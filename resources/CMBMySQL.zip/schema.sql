CREATE TABLE Specimen(
	NCBITax VARCHAR(5),
	SpecID VARCHAR(3),
	Species VARCHAR(10),
	Location VARCHAR(10), 
	PRIMARY KEY (SpecID));
	
CREATE TABLE Gene(
	Symbol VARCHAR(4),
	Name VARCHAR(14),
	RefNCBI VARCHAR(6), 
	PRIMARY KEY (Symbol));
	
CREATE TABLE SequenceData(
	SpecID VARCHAR(3),
	Symbol VARCHAR(4),
	DataFile VARCHAR(8), 
	PRIMARY KEY (SpecID,Symbol),  
	FOREIGN KEY (SpecID) REFERENCES Specimen(SpecID) , 
	FOREIGN KEY (Symbol) REFERENCES Gene(Symbol));
